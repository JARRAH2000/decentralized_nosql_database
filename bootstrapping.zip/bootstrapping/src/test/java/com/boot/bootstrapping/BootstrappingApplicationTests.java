package com.boot.bootstrapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootstrappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
